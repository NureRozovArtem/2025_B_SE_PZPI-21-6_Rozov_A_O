package ua.nure.imemory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IMemoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(IMemoryApplication.class, args);
    }

}
