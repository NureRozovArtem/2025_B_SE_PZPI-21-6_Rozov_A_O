package ua.nure.imemory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IMemoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
